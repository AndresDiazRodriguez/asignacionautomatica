<?php

require_once('./lib/config.php');
require_once('./lib/conexion.php');

function subirArchivo ($archivo) {

    $targetDir = "uploads/";
    $targetFile = $targetDir.basename($archivo["name"]);

    $uploadOK = 1;

    if ($archivo["size"] > 500000000) {
        echo "El archivo a subir es demasiado grande";
        $uploadOK = 0;
    }

    if ($uploadOK == 1) {
	if (move_uploaded_file($archivo["tmp_name"], $targetFile)) {
            echo "El archivo ".htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " ha sido subido correctamente.";
        } 
        else {
            echo "Se presentó un error subiendo el archivo";
        }
    }
}

function cargarDatosTipoYSubtipoRegistro () {

    $conn = $GLOBALS['conn'];

    $datos = array();

    $query = "
    SELECT b.id as idtipo, 
	   a.id as idsubtipo, 
  	   b.nombre as nombretipo, 
	   a.nombre as nombresubtipo 
    FROM subtipoderegistro a 
    INNER JOIN tipoderegistro b ON (b.id = a.tipo) 
    WHERE a.asociadoaproveedor = true OR b.asociadoaproveedor = 1 ";
    $result = pg_query($query) or die ('Query failed: '.pg_last_error());
    while ($fila = pg_fetch_assoc($result)) {
	$idTipo = $fila['idtipo'];
	$idSubtipo = $fila['idsubtipo'];
	$nombreTipo = $fila['nombretipo'];
	$nombreSubtipo = $fila['nombresubtipo'];

        $datos['tipos'][$idTipo] = $nombreTipo;
        $datos['subtipos'][$idSubtipo] = $nombreSubtipo;
	$datos['relacion'][$idTipo][$idSubtipo] = 1;
    }

    pg_free_result($result);

    return json_encode(array("codigoResultado" => 1, "descripcionResultado" => json_encode($datos)));
}

function limpiarVariablesSesion () {
    if (isset($_SESSION['prioridad'])) {
	unset($_SESSION['prioridad']);
    }

    if (isset($_SESSION['horaIngreso'])) {
        // Elimina la variable asignada en sesión para definir una nueva en el siguiente ingreso a la aplicación.
	unset($_SESSION['horaIngreso']);
    }
}

function validarSession () {
    if (empty($_SESSION['idUsuario']) || empty($_SESSION['usuario'])) {
        echo json_encode(array("codigoResultado" => -1, "descripcionResultado" => "Sesión Finalizada"));
	die;
    }
}

function validarImprimirAsistenciasPorPrioridad ($tipoAsistencias) { 
    
    // Esta función es llamada cada cierto tiempo mediante javascript y ajax en el archivo 'index.js'.
    // Se establece el tiempo de ingreso cuando se llama por primera vez y se compara con el tiempo actual en las siguientes ocasiones.
    // Se obtiene la diferencia entre los tiempos mencionados y se compara con la variable global 'TIEMPO_PRIORIDAD_2' y 'TIEMPO_PRIORIDAD_3'.
    // Según el resultado de la comparación se procede a consultar los datos de asistencias según prioridad y a retornar la información para ser impresa.
    
    $tiempoActual = date("Y-m-d H:i:s");

    if (isset($_SESSION['horaIngreso'])) {

        $tiempoInicio = $_SESSION['horaIngreso'];

        $dateInicio = date_create($tiempoInicio);
        $dateActual = date_create($tiempoActual);

        $diferencia = date_diff($dateActual, $dateInicio);
        $diferenciaEnMinutos = $diferencia->format("%i");
        //$diferenciaEnMinutos = $diferencia->format("%s"); // Segundos, para pruebas.

	// Compara la diferencia de minutos y según resultado procede a retornar las asistencias de la prioridad indicada.        
        if ($diferenciaEnMinutos >= $GLOBALS['TIEMPO_PRIORIDAD_3']) {

	    // Establece la variable en sesión para indicar que se muestren solo las de prioridad 3 al llamar las consultas.
	    $_SESSION['prioridad'] = 3; 

            $datosAsistencias = consultarAsistencias($tipoAsistencias, "adicionar");

	    return utf8_encode(json_encode(array("codigoResultado" => 2, "descripcionResultado" => $datosAsistencias, "prioridad" =>  $_SESSION['prioridad'])));
        }
        else if (($diferenciaEnMinutos >= $GLOBALS['TIEMPO_PRIORIDAD_2']) && !isset($_SESSION['banderaPrioridad2Ejecutado'])) {

	    // Define esta variable en sesión para evitar ser llamada multiples veces mientras se ejecuta la prioridad 3.
	    $_SESSION['banderaPrioridad2Ejecutado'] = 1; 

  	    // Establece la variable en sesión para indicar que se muestren solo las de prioridad 2 al llamar las consultas.
	    $_SESSION['prioridad'] = 2;

	    $datosAsistencias = consultarAsistencias($tipoAsistencias, "adicionar");

	    return utf8_encode(json_encode(array("codigoResultado" => 1, "descripcionResultado" => $datosAsistencias, "prioridad" => $_SESSION['prioridad'])));
        }
	else {

	    if (!isset($_SESSION['banderaPrioridad2Ejecutado'])) {
	        // Establece la variable en sesión para indicar que se muestren solo las de prioridad 1 al llamar las consultas.
    	        $_SESSION['prioridad'] = 1;
	    }

	    return utf8_encode(json_encode(array("codigoResultado" => 0, "descripcionResultado" => "Sin tiempo completado aún", "prioridad" => $_SESSION['prioridad'])));
	}
    }
    else {
	
	// Establece la variable de ingreso en sesión, acá se ingresa por primera vez.
        $_SESSION['horaIngreso'] = $tiempoActual;

	// Elimina la variable para que se ejecute solo una vez el la consulta de asistencias prioridad 2.
	if (isset($_SESSION['banderaPrioridad2Ejecutado'])) {
	    unset($_SESSION['banderaPrioridad2Ejecutado']);
  	}

	if (isset($_SESSION['prioridad'])) {
     	    $_SESSION['prioridad'] = 1;
	}

        return utf8_encode(json_encode(array("codigoResultado" => 0, "descripcionResultado" => "Tiempo establecido: ".$tiempoActual, "prioridad" => $_SESSION['prioridad'])));
    }
}

function aceptarServicio ($tipo, $subtipo, $textoTecnico) {

    if (!empty($textoTecnico)) {

    $conn = $GLOBALS['conn'];

    $idAsistencia = $_SESSION['idAsistencia'];
    $NombreUsuario=$_SESSION['nombreUsuario'];
    $idUsuario = $_SESSION['idUsuario'];

    $codigoResultado = 0;
    $descripcionResultado = "";

    // Valida que exista una asistencia y un proveedor para actualizar. 
    // La asistencia proviene del archivo 'ventanaTomarServicio.php', en donde se 
    // recibe mediante el formulario y se almacena como variable de sesión.
    // El proveedor proviene de este archivo en la función 'verificarAccesoProveedor',
    // en donde se consulta el id de proveedor y se almacena comovariable de sesión.
    if (isset($idAsistencia) && $idAsistencia != "" && !empty($idAsistencia)) {
        if (isset($idUsuario) && $idUsuario != "" && !empty($idUsuario)) {

            $query = "
            UPDATE asistencia
            SET proveedor = proveedor.id 
            from proveedor
            WHERE asistencia.id = '".$idAsistencia."'  and proveedor.nombre='".$NombreUsuario."'";
            $result = pg_query($query) or die ('Query failed:'.pg_last_error());

            $codigoResultado = 1;
            $descripcionResultado = "Servicio tomado!";

            pg_free_result($result);

	    // Inserta el registro con el teto definido por el proveedor en la bitácora de la asistencia.
	    insertarRegistro($idAsistencia, $tipo, $subtipo, $textoTecnico);
        }
        else {
            $codigoResultado = 0;
            $descripcionResultado = "No se obtuvo el proveedor";
        }
    }
    else {
        $codigoResultado = 0;
        $descripcionResultado = "No se obtuvo la asistencia";
    }
    }
    else {
        $codigoResultado = 0;
        $descripcionResultado = "Ingrese una observación para tomar el servicio";
    }

    $datosEnvio = array("codigoResultado" => $codigoResultado, "descripcionResultado" => $descripcionResultado);

    return utf8_encode(json_encode($datosEnvio));
}

function insertarRegistro ($idAsistencia, $tipo, $subtipo, $textoTecnico) {

    $conn = $GLOBALS['conn'];

    $idUsuario = consultarIdUsuario($_SESSION['usuario']);

    // Consulta el último id de la tabla registro.
    $query = "
    SELECT MAX(id) as id
    FROM registro ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    $fila = pg_fetch_assoc($result);
    
    $ultimoID = $fila['id'];
    $ultimoID += 1;

    // Inserta el registro en la tabla.
    $query = "
    INSERT INTO registro (id, asistencia, fecha, usuario, tipo, subtipo, comentario)
    VALUES ($ultimoID, $idAsistencia, NOW(), $idUsuario, $tipo, $subtipo, '".$textoTecnico."') ";
    //error_log($query);
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());

    pg_free_result($result);
}

function consultarIdUsuario ($usuario) {

    $conn = $GLOBALS['conn'];

    $query = "
    SELECT id
    FROM \"user\" 
    WHERE username = '".$usuario."' ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    $fila = pg_fetch_assoc($result);

    $idUsuario = $fila['id'];

    pg_free_result($result);

    return $idUsuario;
}

function cargarAsistencias ($tipo) {

    $datosAsistencias = consultarAsistencias($tipo, "cargar");

    $datosEnvio = array("codigoResultado" => 1, "descripcionResultado" => $datosAsistencias, "prioridad" => $_SESSION['prioridad']);

    return utf8_encode(json_encode($datosEnvio));
}


function cargarAsistenciaslibres ($tipo) {

    $datosAsistencias = consultarAsistencias($tipo, "adicionar");

    $datosEnvio = array("codigoResultado" => 1, "descripcionResultado" => $datosAsistencias, "prioridad" => $_SESSION['prioridad']);

    return utf8_encode(json_encode($datosEnvio));
}



function consultarAsistencias ($tipo, $metodo) {

    $conn = $GLOBALS['conn'];

    $arraySalida = array();
    $arrayDatosEspecialidadPorProveedor = array();

    $idUsuario = $_SESSION['idUsuario'];
    $nombreUsuario = $_SESSION['nombreUsuario'];

    $criterioProveedor = "";
    $criterioIdAsistencia = "";
    $criterioMonitoreo = "";

    if (!isset($_SESSION['prioridad'])) {
	$_SESSION['prioridad'] = 1;
    }
    
    // Obtiene la prioridad a mostrar, establecida en la función 'validarImprimirAsistenciasPorPrioridad', según validación de tiempos.
    $prioridad = $_SESSION['prioridad'];

    if ($tipo == "asignadas") {
        $criterioProveedor = "AND proveedor.nombre = '".$nombreUsuario."' ";
    }
    else if ($tipo == "libres") {
        $criterioProveedor = "AND proveedor.nombre IS NULL";
	
	$arrayDatosEspecialidadPorProveedor = consultarEspecialidadProveedor($_SESSION['nombreUsuario']);
    }
    else if ($tipo == "idAsistencia") { // Ingresa acá cuando se abre la ventana de detalle.

	if (empty($_SESSION['idUsuario']) || empty($_SESSION['usuario']) || empty($_SESSION['idAsistencia'])) {
	    echo json_encode(array("codigoRespuesta" => 0));
	    die;
	}

        $idAsistencia = $_SESSION['idAsistencia'];
        $criterioIdAsistencia = "AND asistencia.id = '".$idAsistencia."' ";

        // Obtiene la bitácora de la asistencia.
        $arraySalida['registros'] = consultarRegistros($idAsistencia);

        // Obtiene los archivos adjuntos de la asistencia.
        $arraySalida['adjuntos'] = consultarAdjuntos($idAsistencia);

	$prioridad = "TODO";
    }
    else if ($tipo == "conMonitoreo") {
	$criterioProveedor = "AND proveedor.nombre = '".$nombreUsuario."' ";
	$criterioMonitoreo = "AND asistencia.fechacita IS NOT NULL ";
    }
    else if ($tipo == "sinMonitoreo") {
	$criterioProveedor = "AND proveedor.nombre = '".$nombreUsuario."' ";
        $criterioMonitoreo = "AND asistencia.fechacita IS NULL ";
    }

    if ($prioridad === "TODO") { // Consulta cualquier asistencia, esto cuando se abre el detalle de una.
  	$criterioPrioridad = "";
    }
    else if ($prioridad === 3) { 
	if ($metodo == "cargar") {
	    $criterioPrioridad = "";
	}
	else if ($metodo == "adicionar") {
	    $criterioPrioridad = "AND prioridad.prioridad IN ('3','2','1') ";
	}
    }
    else if ($prioridad === 2) { 
	if ($metodo == "cargar") {
	    $criterioPrioridad = "";
	}
	else if ($metodo == "adicionar") {
	    $criterioPrioridad = "AND prioridad.prioridad IN ('2','1')  ";
	}
    }
    else {
	if ($metodo == "cargar") {
	    $criterioPrioridad = "";
	}

	else if ($metodo == "adicionar") {
	    $criterioPrioridad = "AND prioridad.prioridad ='1'";
	}

    }

    $query = "
    SELECT DISTINCT
           asistencia.*,
           servicio.tipo as serviciotipo,
           servicio.nombre as servicionombre,
           especialidad.nombre as especialidad,
           proveedor.id as proveedorid,
           proveedor.nombre as proveedornombre,
           zona.nombre as zonanombre,
           subzona.nombre as subzonanombre,
           provincia.nombre as provincianombre,
           cuenta.id as cuentaid,
           cuenta.nombre as cuentanombre,
           expediente.nombreafiliado as afiliadoid,
           expediente.nombreafiliado as afiliadonombre,
           expediente.apellidoafiliado as afiliadoapellido,
           expediente.plan as planid,
           \"user\".id as coordinadorid,
           \"user\".username as usernamecoordinador,
           estadoproveedorasistencia.nombre as estadoproveedorasistencianombre,
           estadoasistencia.nombre as estadonombre,
           tipodeservicio.nombre as tiponombre,
           categoriadeasistencia.nombre as categorianombre,
           prioridadcategoria.nombre as prioridadnombre,
	   conceptos.importe as importecosto,
	   prioridad.prioridad as prioridadmayor
    FROM asistencia 
    LEFT JOIN proveedor ON asistencia.proveedor=proveedor.id
    LEFT JOIN expediente ON (asistencia.expediente=expediente.id)
    LEFT JOIN servicio ON (asistencia.servicio=servicio.id)
    LEFT JOIN zona ON expediente.zona = zona.id
    LEFT JOIN cuenta ON (cuenta.id = expediente.cuenta)
    LEFT JOIN \"user\" ON (\"user\".id = expediente.coordinador)
    LEFT JOIN estadoasistencia ON (estadoasistencia.id = asistencia.estado)
    LEFT JOIN tipodeservicio ON (tipodeservicio.id = asistencia.tipo)
    LEFT JOIN provincia ON (provincia.id = asistencia.provincia)
    LEFT JOIN categoriadeasistencia ON (categoriadeasistencia.id = asistencia.categoria) -- TODO
    LEFT JOIN prioridadcategoria ON (prioridadcategoria.id = asistencia.prioridad) -- TOD
    LEFT JOIN subzona ON (subzona.id = asistencia.subzona) -- TOD
    LEFT JOIN estadoproveedorasistencia ON (estadoproveedorasistencia.id = asistencia.estadoproveedorasistencia) -- TODO
    LEFT JOIN proveedorespecialidad ON proveedorespecialidad.proveedor = proveedor.id
    LEFT JOIN especialidad ON especialidad.nombre=servicio.nombre
    LEFT JOIN prioridad ON prioridad.especialidad=especialidad.id
    LEFT JOIN prioridadubicacion ON prioridad.ubicacion=prioridadubicacion.id
    LEFT JOIN ( -- Se une la consulta de suma de importe como tabla para hacer el join con el servicio.id
	  SELECT costo.asistencia as asistencia, costo.servicio as servicio, SUM(costo.importe) as importe
	  FROM costo
	  WHERE costo.usuario = ".$idUsuario." 
	  GROUP BY 1, 2
	) as conceptos ON conceptos.asistencia = asistencia.id AND conceptos.servicio = servicio.id
    WHERE servicio.nombre = especialidad.nombre AND
	  expediente.estado IN (1, 4)
	  ".$criterioIdAsistencia."
	  ".$criterioMonitoreo."
	  ".$criterioPrioridad."
	  ".$criterioProveedor."
    LIMIT 5000 ";
    //error_log($query);


    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    while ($fila = pg_fetch_assoc($result)) {
	
	$zonaNombreAsistencia = $fila['zonanombre'];
	$prioridad = $fila['prioridadmayor'];
	$especialidad = $fila['especialidad'];

	if ($tipo == "libres") {
	    if (isset($arrayDatosEspecialidadPorProveedor[$especialidad])) {
		if (
		    !($arrayDatosEspecialidadPorProveedor[$fila['especialidad']]['nombreZona'] == $zonaNombreAsistencia
		    && $arrayDatosEspecialidadPorProveedor[$fila['especialidad']]['prioridad'] == $prioridad)
	        ) {
		    $arraySalida[] = $fila;
		}
	    }
	}
	else {
	    $arraySalida[] = $fila;
	}
    }

    pg_free_result($result);
    
    return json_encode($arraySalida);
}

function consultarCosto ($idAsistencia) {

    $array = array();

    $query = "
    SELECT SUM(costo.importe) as importe
    FROM costo
    WHERE costo.asistencia = ".$idAsistencia." ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    $fila = pg_fetch_assoc($result);
    pg_free_result($result);

    return json_encode(array("c" => 1, "d" => empty($fila["importe"]) ? 0 : $fila["importe"]));
}

function consultarEspecialidadProveedor ($nombreUsuario) {

    $array = array();

    $query = "
    SELECT DISTINCT
	   prioridad,
           zona.nombre as nombrezona,
           especialidad.nombre as nombreespecialidad
    FROM proveedor 
    INNER JOIN proveedorespecialidad on proveedor.id=proveedorespecialidad.proveedor
    INNER JOIN especialidad on especialidad.id=proveedorespecialidad.especialidad
    INNER JOIN zona on zona.id=proveedor.zona
    INNER JOIN prioridad on especialidad.id = prioridad.especialidad
    WHERE proveedor.nombre = '".$nombreUsuario."' ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    while ($fila = pg_fetch_assoc($result)) {
	$prioridad = $fila['prioridad'];
	$nombreZona = $fila['nombrezona'];
	$nombreEspecialidad = $fila['nombreespecialidad'];

        $array[$nombreEspecialidad]['nombreZona'] = $nombreZona;
	$array[$nombreEspecialidad]['prioridad'] = $prioridad;
    }

    pg_free_result($result);

    return $array;
}

function consultarRegistros ($idAsistencia) {

    $conn = $GLOBALS['conn'];

    $arraySalida = array();

    $query = "
    SELECT a.*,
           b.nombre as tiponombre,
           c.nombre as subtiponombre,
           CONCAT(d.firstname, d.lastname) as usuarionombre,
           f.nombre as proveedornombre
    FROM registro a
    INNER JOIN tipoderegistro b ON (b.id = a.tipo)
    INNER JOIN subtipoderegistro c ON (c.id = a.subtipo)
    INNER JOIN \"user\" d ON (d.id = a.usuario)
    INNER JOIN asistencia e ON (e.id = a.asistencia)
    INNER JOIN proveedor f ON (f.id = e.proveedor)
    WHERE a.asistencia = '".$idAsistencia."' 
    ORDER BY a.fecha DESC ";
    //error_log($query);
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    while ($fila = pg_fetch_assoc($result)) {
        $arraySalida[] = $fila;
    }

    pg_free_result($result);

    return $arraySalida;
}

function consultarAdjuntos ($idAsistencia) {

    $conn = $GLOBALS['conn'];

    $arraySalida = array();

    $query = "
    SELECT * FROM asistenciaadjunto WHERE asistencia = '".$idAsistencia."' ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    while ($fila = pg_fetch_assoc($result)) {
        $arraySalida[] = $fila;
    }

    pg_free_result($result);

    return $arraySalida;
}

function validarPermitirAcceso () {

    if (isset($_POST['usuario']) && isset($_POST['password'])) {
        $usuario = $_POST['usuario'];
        $password = $_POST['password'];

        verificarAccesoUsuario($usuario, $password);
    }
}

function verificarAccesoUsuario ($usuario, $password) {

    list($idUsuario, $nombreUsuario) = consultarDatosUsuario($usuario, $password);
	
    if (empty($idUsuario) && empty($nombreUsuario)) {
	header('Location: login.php?credencialesInvalidas=1');
        exit;
    } else {
	$_SESSION['usuario'] = $usuario;
        $_SESSION['password'] = $password;

        $_SESSION['idUsuario'] = $idUsuario;
	$_SESSION['nombreUsuario'] = $nombreUsuario;

        header('Location: index.php?USUARIO='.$usuario.'?&PASSWORD='.$password.'?&IDUSUARIO='.$idUsuario.'?&NOMBREUSUARIO='.$nombreUsuario);
        exit;
    }
}

function consultarDatosUsuario ($usuario, $password) {

    $conn = $GLOBALS['conn'];

    // Encripta la contraseña para comprala con la que se encuentra en la tabla.
    $passwordEncriptado = encriptarContrasena($password);

	//$passwordEncriptado = $password;

    $query = "
    SELECT \"user\".id, \"user\".username as nombre
    FROM \"user\"
    INNER JOIN doctor_password ON doctor_password.usuario = \"user\".id
    WHERE \"user\".username = '".$usuario."' AND
	  doctor_password.password = '".$password."' AND
          \"user\".active = true ";
    $result = pg_query($query) or die ('Query failed:'.pg_last_error());
    $fila = pg_fetch_assoc($result);


    pg_free_result($result);

    if (isset($fila['id'])) {
        return array($fila['id'], $fila['nombre']);
    }
    else {
        return array("", "");
    }
}

function cargaDatosFiltros () {

    $conn = $GLOBALS['conn'];

    $datos = array();

    $query = "
    SELECT id, 
	   codigo, 
	   nombre 
    FROM cuenta 
    WHERE activado = true 
    ORDER BY nombre ASC ";
    $result = pg_query($query);
    while ($fila = pg_fetch_assoc($result)) {
        $datos['cuenta'][$fila['id']]['codigo'] = $fila['codigo'];
	$datos['cuenta'][$fila['id']]['nombre'] = $fila['nombre'];
    }

    pg_free_result($result);

    $query = "
    SELECT id,
	   cuenta,
	   nombre
    FROM plan
    WHERE activado = true ";
    $result = pg_query($query);
    while ($fila = pg_fetch_assoc($result)) {
	$datos['plan'][$fila['cuenta']][$fila['id']]['nombre'] = $fila['nombre'];
    }

    pg_free_result($result);

    $query = "
    SELECT DISTINCT 
	   a.id, 
  	   a.firstname, 
	   a.lastname 
    FROM \"user\" a 
    INNER JOIN expediente b ON a.id = b.coordinador ";
    $result = pg_query($query);
    while ($fila = pg_fetch_assoc($result)) {
        $datos['coordinador'][$fila['id']]['nombre'] = $fila['lastname']." ".$fila['firstname'];
    }

    pg_free_result($result);

    $query = "
    SELECT id,
           nombre
    FROM tipodeservicio ";
    $result = pg_query($query);
    while ($fila = pg_fetch_assoc($result)) {
        $datos['tipodeservicio'][$fila['id']]['nombre'] = $fila['nombre'];
    }

    pg_free_result($result);

    $query = "
    SELECT id,
	   tipo,
           nombre
    FROM servicio ";
    $result = pg_query($query);
    while ($fila = pg_fetch_assoc($result)) {
        $datos['servicio'][$fila['tipo']][$fila['id']]['nombre'] = $fila['nombre'];
    }

    pg_free_result($result);

    return json_encode(array("codigoResultado" => 1, "descripcionResultado" => json_encode($datos)));
}

function encriptarContrasena($contrasena)
{
    $metodo = $GLOBALS["ENCRYPT_METODO"];
    $llave = $GLOBALS["ENCRYPT_PASSWORD"];
    $opciones = $GLOBALS["ENCRYPT_OPCIONES"];
    $vector = $GLOBALS["ENCRYPT_IV"];

    // Use openssl_encrypt() function to encrypt the data
    return openssl_encrypt($contrasena, $metodo, $llave, $opciones, $vector);
}

