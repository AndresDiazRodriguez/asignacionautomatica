<?php
session_start();
$credencialesInvalidas = 0;
if (isset($_GET['credencialesInvalidas'])) {
    $credencialesInvalidas = $_GET['credencialesInvalidas'];
}
$textoCredencialesInvalidas = "";
if ($credencialesInvalidas) {
    $textoCredencialesInvalidas = "Credenciales Inválidas";
}
?>

<!doctype html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Login Proveedor</title>

    <link href="css/general.css" rel="stylesheet">
    <link rel="stylesheet" href="css/login.css" />
</head>

<body>

    <div class="contenedor">
        <header>
            <h1>IGS</h1>
        </header>
        <form method="POST" action="funciones.php">
            <input type="hidden" name="funcion" value="ingresar">
            <div class="contenido">
                <div class="contenedor-entrada">
                    <label>Usuario</label>
                    <input type="text" name="usuario" required>
                </div>
                <div class="contenedor-entrada">
                    <label>Contraseña</label>
                    <input type="password" name="password" required>
                </div>
                <div class="contenedor-credenciales">
                    <?php echo $textoCredencialesInvalidas; ?>
                </div>
                <div class="contenedor-boton-enviar">
                    <input type="submit" value="Entrar">
                </div>
            </div>
        </form>
    </div>

    <script src="js/login.js"></script>
</body>

</html>