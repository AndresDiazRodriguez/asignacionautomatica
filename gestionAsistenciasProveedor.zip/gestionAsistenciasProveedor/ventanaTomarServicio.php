<?php
require_once("funciones.php");

$idAsistencia = "";
unset($_SESSION['idAsistencia']);

if (isset($_POST['id'])) {
    $_SESSION['idAsistencia'] = $_POST['id'];
    $idAsistencia = $_SESSION['idAsistencia'];
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>IGS Tomar Servicio <?php echo $idAsistencia; ?></title>

    <link href="css/general.css" rel="stylesheet">
    <link href="css/ventanaTomarServicio.css" rel="stylesheet">
</head>

<body>

    <div class="contenedor-contenido">
        <div id="contenido">
	    <div class="seleccion-tipo-contenedor">
		<div class="select-contenedor" id="tipo">
	            <label>Tipo</label>
	 	    <select></select>
		</div>
		<div class="select-contenedor" id="subtipo">
	            <label>Subtipo</label>
	 	    <select></select>
		</div>
	    </div>
            <div class="tab-contenedor" id="tab-contenedor-principal">
                <div class="col col-1">
                <div class="row">
                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia asistencia">
                            <label>Asistencia</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia nombre">
                            <label>Nombre</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia apellido">
                            <label>Apelido</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia direccion">
                            <label>Dirección</label>
                            <span></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia provincia">
                            <label>Provincia</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia zona">
                            <label>Zona</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia subzona">
                            <label>Subzona</label>
                            <span></span>
                        </div>
                    </div>

                    <div class="contenedor-datos-asistencia">
                        <div class="datos-asistencia servicio">
                            <label>Servicio</label>
                            <span></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div>¿DESEA ACEPTAR EL SERVICIO?</div>
		    <div><textarea id="txt-info-tecnica" placeholder="Información Técnica"></textarea></div>
                    <div><input type="button" data-action="aceptar-servicio" value="ACEPTAR SERVICIO"></div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="js/jquery-min.js"></script>
    <script type="text/javascript" src="js/ventanaTomarServicio.js"></script>

</body>

</html>