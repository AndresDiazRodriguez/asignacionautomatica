$(document).ready(function () {
  $(this).on("click", "[data-target]", function (e) {
    imprimirDatos(e, "");
  });
  imprimirDatos("", "principal");
  cargarDatosAsistencia();
});

function imprimirDatos(e, target) {

  if (target == "") {
    var element = e.currentTarget;
    target = $(element).data("target");
  }

  $("#contenido").find(".tab-contenedor").css("display", "none");

  $(".menu-tab a").removeClass("activo");
  $(".menu-tab a[data-target='"+target+"']").addClass("activo");

  switch (target) {
    case "principal":
        $("#tab-contenedor-principal").css("display", "flex");
      break;
    case "bitacora":
        $("#tab-contenedor-bitacora").css("display", "flex");
      break;
    case "adjuntos":
        $("#tab-contenedor-adjuntos").css("display", "flex");
      break;
  }
}

function cargarDatosAsistencia() {
  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "cargarDatosAsistencia",
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);

    if (obj.codigoResultado == -1) {
	alert(obj.descripcionResultado);
        opener.location.href = 'login.php?sesionFinalizada=1';
	window.close();
    }
    else {
    var datos = JSON.parse(obj.descripcionResultado);

    $("#asistencia-numero").text(datos[0].numero);
    $("#asistencia-fechaRegistro").text(datos[0].fecharegistro);
    $("#asistencia-fechaConcluida").text(datos[0].fechaconcluida);
    $("#asistencia-expediente").text(datos[0].expediente);
    $("#asistencia-statusProveedorAsistencia").text(datos[0].estadoproveedorasistencianombre);
    $("#asistencia-statusAsistencia").text(datos[0].estadonombre);
    $("#asistencia-cobertura").prop("checked", function () {
      return datos[0].cobertura == "t" ? "checked" : "";
    });
    $("#asistencia-tipo").text(datos[0].tiponombre);
    $("#asistencia-servicio").text(datos[0].servicionombre);
    $("#asistencia-categoria").text(datos[0].categorianombre);
    $("#asistencia-prioridadAtencion").text(datos[0].prioridadnombre);
    $("#asistencia-disponibilidadFecha1").text(datos[0].disponibilidad1fecha);
    $("#asistencia-disponibilidadHoraDesde1").text(datos[0].disponibilidad1horadesde);
    $("#asistencia-disponibilidadHoraHasta1").text(datos[0].disponibilidad1horahasta);
    $("#asistencia-disponibilidadFecha2").text(datos[0].disponibilidad2fecha);
    $("#asistencia-disponibilidadHoraDesde2").text(datos[0].disponibilidad2horadesde);
    $("#asistencia-disponibilidadHoraHasta2").text(datos[0].disponibilidad2horahasta);
    $("#asistencia-proveedor").text(datos[0].proveedor);
    $("#asistencia-fechaAsignada").text(datos[0].fechaasignacionproveedor);
    $("#asistencia-horaAsignada").text(datos[0].fechaasignacionproveedor);
    $("#asistencia-inicioVigencia").text(datos[0].iniciovigencia);
    $("#asistencia-finVigencia").text(datos[0].finvigencia);
    $("#asistencia-fechaRegistro").text(datos[0].fecharegistro);
    $("#asistencia-encuestada").text(datos[0].encuestada);
    $("#asistencia-comentarios").text(datos[0].comentarios);

    // Imprime los registros de la bitacora.
    datos['registros'].forEach(function(item, index) {
      $("#tab-contenedor-bitacora .col").append(imprimirRegistro(item));
    });

    // Imprime los registros de archivos adjuntos.
    datos['adjuntos'].forEach(function(item, index) {
      $("#tab-contenedor-adjuntos .col").append(imprimirFormularioAdjunto(item));
    });
}
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
    
}

function imprimirFormularioAdjunto (item) {

  var nombreArchivo = item.archivo.split('!')[1];

  var html = "<div class='contenedor-adjunto'>";
  html += "<div><a href='https://201.245.168.171:10443/ApoloProveedoresCloud/upload/"+item.archivo+"'>"+nombreArchivo+"</a></div>";
  html += "<div><input type='button' value='...'><input type='button' value='X'></div>";
  html += "</div>";

  return html;
}

function imprimirRegistro (item) {
  var html = "<div class='contenedor-registro'>";
      html += "<h3>"+item.tiponombre+" "+item.subtiponombre+"</h3>";
      html += "<span>"+item.usuarionombre+" | "+item.fecha+"</span>";
      html += "<span>"+item.proveedornombre+"</span>";
      html += "<span>"+item.comentario+"</span>";
      html += "</div>";
  return html;
}
