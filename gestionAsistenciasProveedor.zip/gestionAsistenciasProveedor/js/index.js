var interval = null;
var datosFiltros = null;
var datosAsistencias = null;

$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {

        var afiliadoFiltro = $(".contenedor-filtro input[data-id='afiliado']").val();
        var proveedorFiltro = $(".contenedor-filtro input[data-id='proveedor']").val();
        var cuentaFiltro = $(".contenedor-filtro select[data-id='cuenta']").val();
        var coordinadorFiltro = $(".contenedor-filtro select[data-id='coordinador']").val();
        var tiposervicioFiltro = $(".contenedor-filtro select[data-id='tipoDeServicio']").val();
        var servicioFiltro = $(".contenedor-filtro select[data-id='servicio']").val();
        var planFiltro = $(".contenedor-filtro select[data-id='plan']").val();

	var afiliado = settings.aoData[dataIndex]._aData.afiliadoid;
	var proveedor = settings.aoData[dataIndex]._aData.proveedor;
        var cuenta = settings.aoData[dataIndex]._aData.cuentaid;
	var coordinador = settings.aoData[dataIndex]._aData.coordinadorid;
	var serviciotipo = settings.aoData[dataIndex]._aData.serviciotipo;
	var servicio = settings.aoData[dataIndex]._aData.servicio;
	var plan = settings.aoData[dataIndex]._aData.planid;

	if (definido(afiliadoFiltro) || definido(proveedorFiltro) || definido(cuentaFiltro) || 
	    definido(coordinadorFiltro) || definido(tiposervicioFiltro) || definido(servicioFiltro) || 
	    definido(planFiltro)) {
	  	
	    if (afiliadoFiltro == afiliado || proveedor == proveedorFiltro || cuenta == cuentaFiltro || coordinador == coordinadorFiltro || 
	    (definido(tiposervicioFiltro) && !definido(servicioFiltro) && tiposervicioFiltro == serviciotipo) ||
	    (definido(tiposervicioFiltro) && definido(servicioFiltro) && servicioFiltro == servicio) || 
	    plan == planFiltro) {
                
		return true;
            }
	    else {
	        return false;
	    }
	}
	return true;
    }
);

$(document).ready(function() {
    $("#contenedor-pestanas-asistencias a").on("click", function () { cargarDatosPestana(this) });
    $(this).on("dblclick", "#tabla-datos[data-type='asignadas'] tr", function (e) { abrirVentanaDetalleAsistencia(e) });
    $(this).on("click", "[data-action='tomar-servicio']", function (e) { abrirVentanaTomarServicio(e) })
    $("#button-filtrar").on("click", function(){filtrar();});
    $(this).on("click", "[data-function='abrir-factura-medica']", function (e) { abrirVentanaFacturaMedica(e) })

    limpiarVariables();

    $("#pestanaActiva").val("libres");
    cargarAsistencias("libres");

    cargarDatosDatosEnFiltros();

    iniciarValidacionAgregarAsistenciasPorPrioridad();
  }
);

function definido (valor) {
  if (valor == "" || valor == undefined || valor == "-") {
    return false;
  }
  return true;
}

function iniciarValidacionAgregarAsistenciasPorPrioridad () {
  interval = setInterval(function(){validarAgregarAsistenciasPorPrioridad()}, 5000);
}

function abrirVentanaTomarServicio (e) {
  var button = e.currentTarget;
  var id = $(button).data("id");
  
  var nombreVentana = "Tomar servicio "+id;

  var form = document.createElement("form");
  form.setAttribute("target", nombreVentana);
  form.setAttribute("method", "post");
  form.setAttribute("action", "ventanaTomarServicio.php");

  var element = document.createElement("input");
  element.setAttribute("type", "hidden");
  element.setAttribute("name", "id");
  element.setAttribute("value", id);
  
  form.appendChild(element);
  
  abrirFormEnVentana(nombreVentana, form);
}

function abrirVentanaFacturaMedica (e) {
  var button = e.currentTarget;
  var idAsistencia = $(button).data("asistencia");

  var nombreVentana = "Factura médica "+idAsistencia;

  var form = document.createElement("form");
  form.setAttribute("target", nombreVentana);
  form.setAttribute("method", "post");
  form.setAttribute("action", "/Archivospwd/formularioMedico/index.php");

  var element = document.createElement("input");
  element.setAttribute("type", "hidden");
  element.setAttribute("name", "idAsistencia");
  element.setAttribute("value", idAsistencia);
  
  form.appendChild(element);
  
  abrirFormEnVentana(nombreVentana, form);
}

function abrirVentanaDetalleAsistencia (e) {
  var tr = e.currentTarget;
  var id = $(tr).find("input[data-id]").data("id");

  var nombreVentana = "Detalle "+id;

  var form = document.createElement("form");
  form.setAttribute("target", nombreVentana);
  form.setAttribute("method", "post");
  form.setAttribute("action", "ventanaDetalleAsistencia.php");

  var element = document.createElement("input");
  element.setAttribute("type", "hidden");
  element.setAttribute("name", "id");
  element.setAttribute("value", id);
  
  form.appendChild(element);
  
  abrirFormEnVentana(nombreVentana, form);
}

function abrirFormEnVentana (nombreVentana, form) {

  var win = window.open("", nombreVentana, "width=800, height=600");
  document.body.appendChild(form);

  form.submit();
  $(form).remove();
}

function cargarDatosPestana(obj) {
  var target = $(obj).data("target");

  $(".contenedor-pestanas a").removeClass("activa");

  switch (target) {
    case "asignadas":
	generarTabla(target);
	$(obj).addClass("activa");
      break;
    case "libres":
	generarTabla(target);
	$(obj).addClass("activa");
      break;
    case "monitoreo-sin-cita":
	generarTabla(target);
	$(obj).addClass("activa");
      break;
    case "monitoreo-con-cita":
	generarTabla(target);
	$(obj).addClass("activa");
      break;
    case "alertas":
	$(obj).addClass("activa");
      break;
  }
}

function generarTabla (tipoAsistencias) {
  cargarAsistencias(tipoAsistencias);

  // Establece el valor para saber en que pestaña se encuentra el usuario.
  $("#pestanaActiva").val(tipoAsistencias);
}

function limpiarVariables () {

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "limpiarVariables"
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {  
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}

function cargarDatosDatosEnFiltros () {

  $selectCuenta = $(".contenedor-filtro select[data-id='cuenta']");
  $selectCoordinador = $(".contenedor-filtro select[data-id='coordinador']");
  $selectTipoDeServicio = $(".contenedor-filtro select[data-id='tipoDeServicio']");

  mostrarCargandoSelect($selectCuenta);
  mostrarCargandoSelect($selectCoordinador);
  mostrarCargandoSelect($selectTipoDeServicio);

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "cargarDatosFiltros"
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);

    if (obj.codigoResultado == -1) {
	alert(obj.descripcionResultado);
        document.location.href = 'login.php?sesionFinalizada=1';
	throw new Error("Sesion Finalizada");
    }

    datosFiltros = JSON.parse(obj.descripcionResultado);

    $selectCuenta.on("change", function(){ imprimirSelectPlan(); });

    $selectCuenta.html("");
    $selectCuenta.append("<option value='-' selected></option>");
    for (const id in datosFiltros['cuenta']) {
      $selectCuenta.append("<option value="+id+">"+datosFiltros['cuenta'][id]['nombre']+"</option>");
    }

    $selectCoordinador.html("");
    $selectCoordinador.append("<option value='-' selected></option>");
    for (const id in datosFiltros['coordinador']) {
      $selectCoordinador.append("<option value="+id+">"+datosFiltros['coordinador'][id]['nombre']+"</option>");
    }

    $selectTipoDeServicio.on("change", function(){ imprimirSelectServicio(); });

    $selectTipoDeServicio.html("");
    $selectTipoDeServicio.append("<option value='-' selected></option>");
    for (const id in datosFiltros['tipodeservicio']) {
      $selectTipoDeServicio.append("<option value="+id+">"+datosFiltros['tipodeservicio'][id]['nombre']+"</option>");
    }
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });

}

function imprimirSelectServicio () {

  $selectServicio = $(".contenedor-filtro select[data-id='servicio']");
  mostrarCargandoSelect($selectServicio);
  $selectServicio.html("");

  var tipoServicio = $(".contenedor-filtro select[data-id='tipoDeServicio']").val();

  $selectServicio.append("<option value='-' selected></option>");
  if (tipoServicio != "-") {
    for (const id in datosFiltros['servicio'][tipoServicio]) {
      $selectServicio.append("<option value="+id+">"+datosFiltros['servicio'][tipoServicio][id]['nombre']+"</option>");
    }
  }
}

function imprimirSelectPlan () {

  $selectPlan = $(".contenedor-filtro select[data-id='plan']");
  mostrarCargandoSelect($selectPlan);
  $selectPlan.html("");

  var cuenta = $(".contenedor-filtro select[data-id='cuenta']").val();

  if (cuenta != "-") {
      $selectPlan.append("<option value='-' selected></option>");
    for (const id in datosFiltros['plan'][cuenta]) {
      $selectPlan.append("<option value="+id+">"+datosFiltros['plan'][cuenta][id]['nombre']+"</option>");
    }
  }
}

function mostrarCargandoSelect (obj) {
  $(obj).append("<option value='-'>CARGANDO...</option>");
}

function validarAgregarAsistenciasPorPrioridad () {

  var tipo = $("#pestanaActiva").val();

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "consultarAsistenciasPorPrioridad",
      tipo: tipo
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);
    var codigo = obj.codigoResultado;

    if (codigo == -1) {
	alert(obj.descripcionResultado);
        document.location.href = 'login.php?sesionFinalizada=1';
	throw new Error("Sesion Finalizada");
    }

    var datos = obj.descripcionResultado;
    
    
    console.log("("+codigo+") IMPRIME PRIORIDAD: "+obj.prioridad);

    if (codigo == 1) { // Se retornan datos para imprimir en tabla.
	agregarDatosATabla(tipo, datos);
    }
    else if (codigo == 2) { // Se imprimen los datos y se elimina el timer.
	agregarDatosATabla(tipo, datos);
        clearInterval(interval);
        console.log("DESTRUYE INTERVLO");
    }  
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}

function cargarAsistencias (tipo) {

  mostrarCargando("contenedor-contenido");

  $(".contenedor-pestanas a").removeClass("activa");
  $("#contenedor-pestanas-asistencias").find("[data-target='"+tipo+"']").addClass("activa");

  var funcion = "";

  var encabezadoTabla = [];

  if (tipo == "asignadas") {
    funcion = "cargarAsistenciasAsignadas";
    
    var encabezadoTabla = [
        "Número",
        "Fecha Apertura",
        "Servicio",
        "Proveedor",
        "Zona",
        "Dirección",
        "Cuenta",
        "Nombre",
        "Apellido",
        "Usuario",
        "Fecha Cita",
        "Columna Final",
        ""
    ];
  }
  else {
    if (tipo == "libres") {
      funcion = "cargarAsistenciasLibres";
    }
    else if (tipo == "monitoreo-con-cita") {
      funcion = "cargarAsistenciasConMonitoreo";
    }
    else if (tipo == "monitoreo-sin-cita") {
      funcion = "cargarAsistenciasSinMonitoreo";
    }

    var encabezadoTabla = [
        "Número",
        "Fecha Apertura",
        "Servicio",
        "Proveedor",
        "Zona",
        "Dirección",
        "Cuenta",
        "Nombre",
        "Apellido",
        "Usuario",
        "Fecha Cita",
        ""
    ];
  }
  

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: funcion,
      pestana: $("#pestanaActiva").val()
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);

    if (obj.codigoResultado == -1) {
	alert(obj.descripcionResultado);
        document.location.href = 'login.php?sesionFinalizada=1';
	throw new Error("Sesion Finalizada");
    }

    var datos = JSON.parse(obj.descripcionResultado);

    $("#contenedor-contenido").html("");

    $("#contenedor-contenido").append("<table id='tabla-datos' data-type='"+tipo+"' class='nowrap' width='100%'><thead><tr></tr></thead></table>"); 
    for (encabezado in encabezadoTabla) {
        $("#tabla-datos thead tr").append("<th>"+encabezadoTabla[encabezado]+"</th>");
    }
    
    generarDatosEnTabla(tipo, datos);

  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}

function agregarDatosATabla(tipo, datosJSON) {

    var table = $("#tabla-datos").DataTable();
    var arrayFinal = [];

    datos = JSON.parse(datosJSON);

    if (tipo == "asignadas") {

	datos.forEach(function(item, index) {
	    var datosAgregar = {
		numero : item.numero, 
		fechasolicitud : item.fechasolicitud, 
		servicionombre : item.servicionombre, 
		proveedornombre : item.proveedornombre, 
		zonanombre : item.zonanombre, 
		direccionmaps : item.direccionmaps, 
		cuentanombre : item.cuentanombre, 
		afiliadonombre : item.afiliadonombre, 
		afiliadoapellido : item.afiliadoapellido, 
		usernamecoordinador : item.usernamecoordinador, 
		fechacita : item.fechacita,
	        importecosto : item.importecosto,
		id : item.id
	    };
    	    
	    arrayFinal.push(datosAgregar);
	});

    }
    else if (tipo == "libres") {
	
	datos.forEach(function(item, index) {
	    var idItem = item.id;
	    var datosAgregar = {
		numero : item.numero, 
		fechasolicitud : item.fechasolicitud, 
		servicionombre : item.servicionombre, 
		proveedornombre : item.proveedornombre, 
		zonanombre : item.zonanombre, 
		direccionmaps : item.direccionmaps, 
		cuentanombre : item.cuentanombre, 
		afiliadonombre : item.afiliadonombre, 
		afiliadoapellido : item.afiliadoapellido, 
		usernamecoordinador : item.usernamecoordinador, 
		fechacita : item.fechacita,
		id : idItem
	    };
    	    
	    arrayFinal.push(datosAgregar);
	});
    }

    if (arrayFinal.length > 0) {
      arrayFinal.forEach(function(item, index) {
        table.row.add(item);
      });
      table.draw();
    }
}

function generarDatosEnTabla(tipo, datos) {

    if (tipo == "asignadas" || tipo == "monitoreo-con-cita" || tipo == "monitoreo-sin-cita") {

        $("#tabla-datos").DataTable({
        data: datos,
        scrollY: "50vh",
        scrollX: true,
        scrollCollapse: true,
        paging: false,
        destroy: true,
        info: false,
        columns: [
            { data: "numero" },
            { data: "fechasolicitud" },
            { data: "servicionombre" },
            { data: "proveedornombre" },
            { data: "zonanombre" },
            { data: "direccionmaps" },
            { data: "cuentanombre" },
            { data: "afiliadonombre" },
            { data: "afiliadoapellido" },
            { data: "usernamecoordinador" },
            { data: "fechacita" },
            { 
	      data: "importecosto",
	      render: function (data, type, row) {
                if (!data) {
                  data = 0;
                }
    	        //return "<input  type='text' id='txt-costo-"+row.id+"' class='input-importe' value='"+data+"' disabled>";
		return "<label>a</label>";
	      }
	    },
            { 
              data: "id",
              render: function (data, type, row) {
                //return "<input type='button' value='Factura médica' data-function='abrir-factura-medica' data-asistencia='"+row.id+"'><input type='hidden' data-function='filtros' data-id='"+data+"'>";
                return "<input type='hidden' data-function='filtros' data-id='"+data+"'>";
		}
            },
        ],
    });    
    }
    else if (tipo == "libres") {

      $("#tabla-datos").DataTable({
            data: datos,
            scrollY: "50vh",
            scrollX: true,
            scrollCollapse: true,
            paging: false,
            destroy: true,
            info: false,
            columns: [
              { data: "numero" },
              { data: "fechasolicitud" },
              { data: "servicionombre" },
              { data: "proveedornombre" },
              { data: "zonanombre" },
              { data: "direccionmaps" },
              { data: "cuentanombre" },
              { data: "afiliadonombre" },
              { data: "afiliadoapellido" },
              { data: "usernamecoordinador" },
              { data: "fechacita" },
              { 
                data: "id",
                render: function (dato, type, row) {
                  return "<input type='button' value='Tomar Servicio' data-function='filtros' data-action='tomar-servicio' data-id='"+dato+"'>";
                }
              },
          ],
      });    
    }
}

function mostrarCargando(div) {
    $("#" + div).html("<img class='cargando' src='img/cargando.gif' />");
}

function filtrar () {
    $("#tabla-datos").DataTable().draw();
}

function actualizarValorCosto (id) {
  
  $("#txt-costo-"+id).val("CARGANDO...");

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: 'consultarCosto',
      id: id
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);

    if (obj.c == 1) {
      $("#txt-costo-"+id).val(obj.d);
    }
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}