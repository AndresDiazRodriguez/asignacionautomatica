var datosTipoYSubtipo = "";

$(document).ready(function () {
  cargarDatosTipoYSubtipo();
  cargarDatosAsistencia();
  $(this).on("click", "[data-action='aceptar-servicio']", function() { aceptarServicio(this); })
});

function aceptarServicio (buttonObject) {

  $(buttonObject).prop("disabled", true);

  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "aceptarServicio",
      tipo: $("#tipo select").val(),
      subtipo: $("#subtipo select").val(),
      texto: $("#txt-info-tecnica").val()
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);
    var codigo = obj.codigoResultado;
    var respuesta = obj.descripcionResultado;

    if (codigo == -1) {
	alert(obj.descripcionResultado);
        opener.location.href = 'login.php?sesionFinalizada=1';
	window.close();
    }
    else if (codigo == 1) {
	alert(respuesta);
        window.opener.cargarAsistencias('asignadas');
	window.close();
    }
    else {
        alert(respuesta);
    }

    $(buttonObject).prop("disabled", false);
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}

function cargarDatosTipoYSubtipo () {
  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "cargarDatosTipoYSubtipo",
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {
    var obj = JSON.parse(msg);

    if (obj.codigoResultado == -1) {
	alert(obj.descripcionResultado);
        opener.location.href = 'login.php?sesionFinalizada=1';
	window.close();
    }
    else {

        datosTipoYSubtipo = JSON.parse(obj.descripcionResultado);

        $selectTipo = $("#tipo select");
        $selectSubtipo = $("#subtipo select");

        $selectTipo.on("change", function(){imprimirSubtipos()})

        for (const index in datosTipoYSubtipo.tipos) {
            $selectTipo.append("<option value="+index+">"+datosTipoYSubtipo.tipos[index]+"</option>");
        }

        imprimirSubtipos();
    }
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}

function imprimirSubtipos() {

    tipoSelect = $("#tipo select").val();

    $selectSubtipo = $("#subtipo select");

    $selectSubtipo.html("");

    for (const idSubtipo in datosTipoYSubtipo.relacion[tipoSelect]) {
        $selectSubtipo.append("<option value="+idSubtipo+">"+datosTipoYSubtipo.subtipos[idSubtipo]+"</option>");
    }
}

function cargarDatosAsistencia () {
  var request = $.ajax({
    url: "funciones.php",
    method: "POST",
    data: {
      funcion: "cargarDatosAsistencia",
    },
    //dataType: "json",
    dataType: "html",
  });

  request.done(function (msg) {

    var obj = JSON.parse(msg);

    if (obj.codigoResultado == -1) {
	alert(obj.descripcionResultado);
        opener.location.href = 'login.php?sesionFinalizada=1';
	window.close();
    }
    else {
        var datos = JSON.parse(obj.descripcionResultado);

        $(".datos-asistencia.asistencia span").text(datos[0].numero+" "+datos[0].servicionombre);
        $(".datos-asistencia.nombre span").text(datos[0].afiliadonombre);
        $(".datos-asistencia.apellido span").text(datos[0].afiliadoapellido);
        $(".datos-asistencia.direccion span").text(datos[0].direccion);
        $(".datos-asistencia.provincia span").text(datos[0].provincianombre);
        $(".datos-asistencia.zona span").text(datos[0].zonanombre);
        $(".datos-asistencia.subzona span").text(datos[0].subzonanombre);
        $(".datos-asistencia.servicio span").text(datos[0].servicionombre);
      }
  });

  request.fail(function (jqXHR, textStatus) {
    alert("Request failed: " + textStatus);
  });
}
