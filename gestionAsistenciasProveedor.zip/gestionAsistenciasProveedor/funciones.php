<?php
session_start();

require_once "./datos/datos.php";

if (isset($_POST['funcion'])) {

    $funcion = $_POST['funcion'];

    if ($funcion == "ingresar") {
        validarPermitirAcceso();
    }
    
    echo validarSession();

    if ($funcion == "limpiarVariables") {
	limpiarVariablesSesion();
    }
    else if ($funcion == "cargarAsistenciasAsignadas") {
        echo cargarAsistencias("asignadas");
    }
    else if ($funcion == "cargarAsistenciasLibres") {
        echo cargarAsistenciaslibres("libres");
    }
    else if ($funcion == "cargarDatosAsistencia") {
        echo cargarAsistencias("idAsistencia");
    }
    else if ($funcion == "cargarAsistenciasConMonitoreo") {
        echo cargarAsistencias("conMonitoreo");
    }
    else if ($funcion == "cargarAsistenciasSinMonitoreo") {
        echo cargarAsistencias("sinMonitoreo");
    }
    else if ($funcion == "cargarDatosFiltros") {
        echo cargaDatosFiltros();
    }
    else if ($funcion == "aceptarServicio") {
	$tipo = $_POST['tipo'];
	$subtipo = $_POST['subtipo'];
	$textoTecnico = $_POST['texto'];
	echo aceptarServicio($tipo, $subtipo, $textoTecnico);
    }
    else if ($funcion == "consultarAsistenciasPorPrioridad") {
	$tipoAsistencias = $_POST['tipo'];
        echo validarImprimirAsistenciasPorPrioridad($tipoAsistencias);
    }
    else if ($funcion == "cargarDatosTipoYSubtipo") {
	echo cargarDatosTipoYSubtipoRegistro();
    }
    else if ($funcion == "subirArchivo") {
	$archivo = $_FILES["archivo"];
	echo subirArchivo($archivo);
    }
    else if ($funcion == "consultarCosto") {
        $id = $_POST["id"];
        echo consultarCosto($id);
    }
}