<?php
session_start();

require_once './datos/datos.php';

// Verifica que el usuario guardado siga activo.
if (empty($_SESSION["usuario"]) || empty($_SESSION["password"]) || empty($_SESSION["idUsuario"])) {
    header('Location: login.php?VACIO=1');
    exit;
} else {
    $usuario = $_SESSION["usuario"];
    $password = $_SESSION["password"];

    $verificacion = verificarUsuarioActivo($usuario, $password);
    if (!$verificacion) {
        header('Location: login.php?credencialesInvalidas=1');
        exit;
    }
}

function verificarUsuarioActivo($usuario, $password) {
    list($id, $nombre) = consultarDatosUsuario($usuario, $password);
    if (empty($id)) {
      return 0;
    }
    return 1;
}

?>

<!doctype html>
<html>

<head>
    <meta charset="utf-8" />
    <title>IGS Proveedores</title>

    <link href="css/dataTables.min.css" rel="stylesheet">
    <link href="css/general.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet">
</head>

<body>
    <header>
        <nav></nav>
    </header>
    <div class="contenedor">
        <header><i>Asitencias</i></header>
        <div class="contenido">
            <div class="contenedor-filtros">

		<div class="contenedor-filtros-campos">
	        <div class="contenedor-filtro">
		    <label>ID Afiliado</label>
		    <input type="text" data-action="filtro" data-id="afiliado">
	        </div>

	        <div class="contenedor-filtro">
		    <label>Expediente</label>
		    <input type="text" data-action="filtro" data-id="expediente">
	        </div>

	        <div class="contenedor-filtro">
		    <label>Cuenta</label>
		    <select data-action="filtro" data-id="cuenta"></select>
	        </div>

	        <div class="contenedor-filtro">
		    <label>Plan</label>
		    <select data-action="filtro" data-id="plan"></select>
	        </div>

	        <div class="contenedor-filtro">
		    <label>Coordinador</label>
		    <select data-action="filtro" data-id="coordinador"></select>
	        </div>

	        <div class="contenedor-filtro">
		    <label>Tipo de servicio</label>
		    <select data-action="filtro" data-id="tipoDeServicio"></select>
	        </div>

	        <div class="contenedor-filtro">
		    <label>Servicio</label>
		    <select data-action="filtro" data-id="servicio"></select>
	        </div>

	        <div class="contenedor-filtro">
		    <label>Proveedor</label>
		    <input type="text" data-action="filtro" data-id="proveedor">
	        </div>
		</div>
	
		<div class="contenedor-boton">
		    <input type="button" id="button-filtrar" value="Filtrar">
		</div>

	    </div>
            <div class="contenedor-datos">
                <div id="contenedor-pestanas-asistencias" class="contenedor-pestanas">
                    <a href="#" data-target="asignadas">Asignados</a>
                    <a href="#" data-target="libres">Libres</a>
                    <a href="#" data-target="monitoreo-sin-cita">Monitoreo Sin Cita</a>
                    <a href="#" data-target="monitoreo-con-cita">Monitoreo Con Cita</a>
                    <a href="#" data-target="alertas">Alertas</a>
                </div>
                <div id="contenedor-contenido"></div>
            </div>
        </div>
    </div>
    
    <input type="hidden" id="pestanaActiva" />

    <script type="text/javascript" src="js/jquery-min.js"></script>

    <!-- Data Table, for large amount of data in tables -->
    <script type="text/javascript" src="js/datatables.min.js"></script>

    <script src="js/index.js"></script>    

</body>

</html>