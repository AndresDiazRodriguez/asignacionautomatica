<?php

require_once './config.php';

$pass = "test";

echo $pass."=>".encriptarContrasena($pass);

function encriptarContrasena($contrasena)
{
    $metodo = $GLOBALS["ENCRYPT_METODO"];
    $llave = $GLOBALS["ENCRYPT_PASSWORD"];
    $opciones = $GLOBALS["ENCRYPT_OPCIONES"];
    $vector = $GLOBALS["ENCRYPT_IV"];

    // Use openssl_encrypt() function to encrypt the data
    return openssl_encrypt($contrasena, $metodo, $llave, $opciones, $vector);
}


