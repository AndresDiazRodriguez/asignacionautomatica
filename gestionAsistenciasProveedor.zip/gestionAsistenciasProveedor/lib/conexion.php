<?php

header("Access-Control-Allow-Origin: *");

require_once('config.php');

// Par�metros de conexi�n a la base de datos.
$servername = $DB_SERVER_NAME;
$username = $DB_USER_NAME;
$password = $DB_PASSWORD;
$db = $DB;

// Realiza la conexi�n a la base de datos.
$conn = pg_connect("host=$servername dbname=$db user=$username password=$password") or die('Could not connect: ' . pg_last_error());

?>