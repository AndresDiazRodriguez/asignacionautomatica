<?php

header("Access-Control-Allow-Origin: *");

// ************** PARÁMETROS DE CONEXIÓN A POSTGRESQL ************** //

$DB_SERVER_NAME = '192.168.15.2';
$DB_USER_NAME = 'postgres';
$DB_PASSWORD = 'DIAN2208';
$DB = 'eeuu';

// ************** FIN PARÁMETROS DE CONEXIÓN A POSTGRESQL ************** //

// ************** PARÁMETROS DE CONSULTA DE ASISTENCIAS POR PRIORIDAD ************** //

//$TIEMPO_PRIORIDAD_3 = 2; // Cantidad de minutos a esperar después de ingresar para mostrar.
//$TIEMPO_PRIORIDAD_2 = 1; // Cantidad de minutos a esperar después de ingresar para mostrar.

$TIEMPO_PRIORIDAD_3 = 3; // Cantidad de segundos, PRUEBAS.
$TIEMPO_PRIORIDAD_2 = 2; // Cantidad de segundos, PRUEBAS.

// ************** FIN PARÁMETROS DE CONSULTA DE ASISTENCIAS POR PRIORIDAD ************** //

// ************** PARÁMETROS DE ENCRIPTACIÓN ************** //

$ENCRYPT_METODO = "AES-256-CBC";
$ENCRYPT_PASSWORD = "#igs_doctor";
$ENCRYPT_OPCIONES = 0;
$ENCRYPT_IV = "1234567891011121";

// ************** FIN PARÁMETROS DE ENCRIPTACIÓN ************** //

?>