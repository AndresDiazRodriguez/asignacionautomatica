<?php
require_once("funciones.php");
$script = null;

$idAsistencia = "";
unset($_SESSION['idAsistencia']);

if (isset($_POST['id'])) {
    $_SESSION['idAsistencia'] = $_POST['id'];
    $idAsistencia = $_SESSION['idAsistencia'];
}
else {
    echo json_encode(array("codigoRespuesta" => 0));
    die;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>IGS Detalle <?php echo $idAsistencia; ?></title>

    <link href="css/general.css" rel="stylesheet">
    <link href="css/ventanaDetalleAsistencia.css" rel="stylesheet">

</head>

<body>

    <div class="contenedor-contenido">

        <nav class="menu-tab">
            <a href="#" data-target="principal">Principal</a>
            <a href="#" data-target="bitacora">Bitácora</a>
            <a href="#" data-target="adjuntos">Adjuntos</a>
        </nav>

        <div id="contenido">

            <div class="tab-contenedor" id="tab-contenedor-principal">

                <div class="col">

                    <div class="contenedor-grupo-2">
                        <label>Número</label>
                        <span id="asistencia-numero"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Fecha Registro</label>
                        <span id="asistencia-fechaRegistro"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Fecha Concluida</label>
                        <span id="asistencia-fechaConcluida"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Expediente</label>
                        <span id="asistencia-expediente"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Status proveedor asistencia</label>
                        <span id="asistencia-statusProveedorAsistencia"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Status asistencia</label>
                        <span id="asistencia-statusAsistencia"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Cobertura</label>
                        <input type="checkbox" id="asistencia-cobertura" readonly />
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Tipo</label>
                        <span id="asistencia-tipo"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Servicio</label>
                        <span id="asistencia-servicio"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Categoría</label>
                        <span id="asistencia-categoria"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Prioridad Atencion</label>
                        <span id="asistencia-prioridadAtencion"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Disponibilidad 1</label>
                        <span id="asistencia-disponibilidadFecha1"></span>
                    </div>

                    <div class="contenedor-grupo-3">
                        <label>Hora</label>
                        <span id="asistencia-disponibilidadHoraDesde1"></span>
                        <span id="asistencia-disponibilidadHoraHasta1"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Disponibilidad 1</label>
                        <span id="asistencia-disponibilidadFecha2"></span>
                    </div>

                    <div class="contenedor-grupo-3">
                        <label>Hora</label>
                        <span id="asistencia-disponibilidadHoraDesde2"></span>
                        <span id="asistencia-disponibilidadHoraHasta2"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Proveedor</label>
                        <span id="asistencia-proveedor"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Fecha Asignada</label>
                        <span id="asistencia-fechaAsignada"></span>
                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Hora Asignada</label>
                        <span id="asistencia-horaAsignada"></span>
                    </div>

                    <div class="contenedor-grupo-3">

                        <div class="contenedor-grupo-2">
                            <label>Inicio Vigencia</label>
                            <span id="asistencia-inicioVigencia"></span>
                        </div>

                        <div class="contenedor-grupo-2">
                            <label>Fin Vigencia</label>
                            <span id="asistencia-finVigencia"></span>
                        </div>

                        <div class="contenedor-grupo-2">
                            <label>Fecha Registro</label>
                            <span id="asistencia-fechaRegistro"></span>
                        </div>

                    </div>

                    <div class="contenedor-grupo-2">
                        <label>Encuestada</label>
                        <span id="asistencia-encuestada"></span>
                    </div>

                </div>

                <div class="col">

                    <div class="contenedor-grupo-2-v">
                        <label>Comentarios</label>
                        <textarea id="asistencia-comentarios"></textarea>
                    </div>

                </div>

            </div>

            <div class="tab-contenedor" id="tab-contenedor-bitacora">
                <div class="col col-1"></div>
            </div>

            <div class="tab-contenedor" id="tab-contenedor-adjuntos">
                <div class="col col-1"></div>
		<form class="contenedor-nuevo" action="funciones.php" method="post" enctype="multipart/form-data" target="iframe-upload">
		    <input type="hidden" name="funcion" value="subirArchivo">
		    <div><i>Subir Nuevo Archivo</i></div>
                    <div><input type="file" name="archivo"></div>
		    <div><input type="submit" class="boton-subir" value="Subir"></div>
	        </form>
            </div>

	    <iframe name="iframe-upload"></iframe>

        </div>

    </div>

    <script type="text/javascript" src="js/jquery-min.js"></script>
    <script type="text/javascript" src="js/ventanaDetalleAsistencia.js"></script>

</body>

</html>